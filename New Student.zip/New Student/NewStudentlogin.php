<!DOCTYPE HTML>

<html>

<head>

<title>

Student Registration

</title>

<style>

}

</style>

</head>

<body>

<div>

<h2 style="margin-left:30px"> No account please fill out the New Student Registration </h2>

<a href="index2.php"><i class="fas fa-user-circle"></i>Login</a>
				
<table>

<form method="post" action="NewStudentLogin.php">
<tr><td>ID : </td><td><input type="number" name="id" ></td></tr>

<tr><td>username : </td><td><input type="number" name="username" ></td></tr>

<tr><td>SSN : </td><td><input type="number" name="SSN" ></td></tr>

<tr><td>Email :</td><td><input type="email" name="Email" ></td></tr>

<tr><td>Password :</td><td><input type="password" name="Password" ></td></tr>

<tr><td>First Name :</td><td> <input type="text" name="FirstName" ></td></tr>

<tr><td>Last Name :</td><td> <input type="text" name="LastName" ></td></tr>

<tr><td>Address:</td><td ><textarea name="Address" rows="2" ></textarea></td></tr>

<tr><td>Phone :</td><td> <input type="number" name="Phone" ></td></tr>

<tr><td>Grade :</td><td> <input type="number" name="Grade" ></td></tr>

<tr><td>Math : </td><td><input type="text" name="math" ></td></tr>

<tr><td>English : </td><td><input type="text" name="english" ></td></tr>

<tr><td>Science :</td><td><input type="text" name="science" ></td></tr>

<tr><td>History :</td><td><input type="text" name="history" ></td></tr>

<tr><td colspan="2"><input type="submit" name="submit"></td></tr>

</form>


</table>

</div>

</body>

</html>

<?php

$servername = "localhost:3086";

$username = "root";

$password = "";

$dbname = "new student user";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection

if ($conn->connect_error) {

die("Connection failed: " . $conn->connect_error);

}

if($_POST){
$id =$_POST["id"];

$username =$_POST["username"];

$ssn =$_POST["SSN"];

$email =$_POST["Email"];

$pass =$_POST["Password"];

$fname = $_POST["FirstName"];

$lname = $_POST["LastName"];

$addres =$_POST["Address"];

$phone =$_POST["Phone"];

$grade =$_POST["Grade"];

$math =$_POST["math"];

$english =$_POST["english"];

$science =$_POST["science"];

$history =$_POST["history"];

// Create connection

$sql = "INSERT INTO tbluser2 (id,username,ssn,email,password,firstname,lastname,address,phone,grade,math,english,science,history)

VALUES ('{$id}', '{$username}', '{$ssn}', '{$email}', '{$pass}', '{$fname}', '{$lname}', '{$addres}', '{$phone}', '{$grade}','{$math}', '{$english}', '{$science}', '{$history}')";

if ($conn->query($sql) === TRUE){

echo "<font color='green'>Information Submitted Successfully</font>";

exit();

}

else {

echo "Error: " . $sql . "<br>" . $conn->error;

}

$conn->close();

}

?>

