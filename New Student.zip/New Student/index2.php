<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		
	</head>
	<body>
		<div class="login">
			<h1>Login</h1>
			<form action="authenticatenew.php" method="post">
				<label for="username">
					<i class="fas fa-user"></i>
				</label>
				<input type="text" name="username" placeholder="Username" id="username" required>
				<label for="password">
					<i class="fas fa-lock"></i>
				</label>
				<input type="password" name="password" placeholder="Password" id="password" required>
				<input type="submit" value="Login">
			</form>
			<a href="NewStudentlogin.php"><i class="fas fa-user-circle"></i>Register</a>
		</div>
	</body>
</html>