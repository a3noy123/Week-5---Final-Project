<?php

session_start();

if (!isset($_SESSION['loggedin'])) {
	header(`Location: index2.php`);
	exit;
}
$DATABASE_HOST = "localhost:3086";
$DATABASE_USER = "root";
$DATABASE_PASS = "";
$DATABASE_NAME = "new student user";
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()){
	exit(`Failed to connect to MySQL:` . mysqli_connect_error());
	
}

$stmt = $con->prepare('SELECT username, password, email, firstName, lastName, address, phone, grade, math, english, science, history FROM tbluser2 WHERE id = ?');

$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($username, $password, $email, $firstName, $lastName, $address, $phone, $grade, $math, $english, $science, $history);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Profile Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Student Info</h1>
				<a href="Profilenew.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="logoutnew.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Profile Page</h2>
			<div>
				<p>Your Student class details are below:</p>
<table>

<form method="post" action="NewStudentLogin.php">
<tr><td>ID : </td><td><input type="number" name="id" ></td></tr>

<tr><td>username : </td><td><input type="number" name="username" ></td></tr>

<tr><td>SSN : </td><td><input type="number" name="SSN" ></td></tr>

<tr><td>Email :</td><td><input type="email" name="Email" ></td></tr>

<tr><td>Password :</td><td><input type="password" name="Password" ></td></tr>

<tr><td>First Name :</td><td> <input type="text" name="FirstName" ></td></tr>

<tr><td>Last Name :</td><td> <input type="text" name="LastName" ></td></tr>

<tr><td>Address:</td><td ><textarea name="Address" rows="2" ></textarea></td></tr>

<tr><td>Phone :</td><td> <input type="number" name="Phone" ></td></tr>

<tr><td>Grade :</td><td> <input type="number" name="Grade" ></td></tr>

<tr><td>Math : </td><td><input type="text" name="math" ></td></tr>

<tr><td>English : </td><td><input type="text" name="english" ></td></tr>

<tr><td>Science :</td><td><input type="text" name="science" ></td></tr>

<tr><td>History :</td><td><input type="text" name="history" ></td></tr>

</form>


</table>

</div>




