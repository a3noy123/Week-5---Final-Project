<!DOCTYPE HTML>

<html>

<head>

<title>

Add class / Delete class

</title>

<style>

}

</style>

</head>

<body>

<div>

<h2 style="margin-left:30px"> Add class / Delete class </h2>

<a href="Profilenew.php"><i class="fas fa-user-circle"></i>Profile</a>
				
<table>

<form method="post" action="Add_Delete.php">

<tr><td>Math : </td><td><input type="text" name="math" ></td></tr>

<tr><td>English : </td><td><input type="text" name="english" ></td></tr>

<tr><td>Science :</td><td><input type="text" name="science" ></td></tr>

<tr><td>History :</td><td><input type="text" name="history" ></td></tr>

<tr><td colspan="2"><input type="submit" name="submit"></td></tr>

</form>

</table>

</div>

</body>

</html>

<?php

$servername = "localhost:3086";

$username = "root";

$password = "";

$dbname = "new student user";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection

if ($conn->connect_error) {

die("Connection failed: " . $conn->connect_error);

}

if($_POST){

$math =$_POST["math"];

$english =$_POST["english"];

$science =$_POST["science"];

$history =$_POST["history"];

// Create connection

$sql = "INSERT INTO class (math,english,science,history)

VALUES ('{$math}', '{$english}', '{$science}', '{$history}')";

if ($conn->query($sql) === TRUE){

echo "<font color=`green`>Information Submitted Successfully</font>";

exit();

}

else {

echo "Error: " . $sql . "<br>" . $conn->error;

}

$conn->close();

}

?>

